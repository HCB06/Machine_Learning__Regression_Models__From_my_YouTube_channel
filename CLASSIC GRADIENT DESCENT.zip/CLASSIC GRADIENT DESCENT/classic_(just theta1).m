function lineer(X,y)

alfa=0.01;

m=length(y);

theta=zeros(1,1);
teta=zeros(1,1);



% MALİYET HESAPLAMA VE AZALTMA
i=1;
do
i++;
h=X*theta;

maliyet_top = (h-y).^2;
j(i)=1/(2*m)*sum(maliyet_top);
if j(i)==j(2)
j(1)=j(2);
end
theta(1,1) = theta(1,1) - alfa * (1/m)*(X'*(h-y));
teta(i,1) = theta(1,1);
to_infinity=i
until (j(i)>j(i-1))

plot(X(:,1),y,'rx','MarkerSize',7)
hold on
plot(X(:,1),X*theta,'-')


disp("Maliyet Yoldulugu:")
j(:)

disp("Teta yolculugu:")
teta(:,1)

disp("Toplam Gidilen Adımlar: (iterasyon)")
i

disp("Minimum Maliyet Degeri:")
min(j)

disp("Bulunan teta degerleri:")

theta



% MALİYET DEĞERLERİ İLE BİRLİKTE EN DÜŞÜK MALİYET NOKTASINI VE TETA DEĞERLERİNİN YOLUCUĞUNU 3 BOYUTLU BİÇİMDE GÖRMEK İÇİN 3 BOYUTLU GRAFİK OLUŞTURMA
 
			% Maliyet fonksiyonunun hesapladığı maliyet değerlerini matris olarak varsayalım


			% Maliyet değerlerini 3D çizgi grafiğiyle gösterme
			figure;
			plot3(teta(:,1), j, '.', 'MarkerSize', 10);
			hold on;
		
			plot3(theta(1,1), min(j), 'r.', 'MarkerSize', 20);
			
			
			legend('Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası','Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası')
			
			
			hold off;
			title('Maliyet Fonksiyonunun Minimizasyonu 3D Çizimi (Mavi Nokta: Maliyet Değeri, Kırmızı Nokta: Destinasyon)');
			xlabel('Theta1');
			ylabel('Maliyet');
			zlabel('Theta0');
			grid on;
