function classic(X,y)

alfa=0.01;

m=length(y);

theta=zeros(2,1);
teta=zeros(1,2);

X = [ones(m,1),X];


% MALİYET HESAPLAMA
i=1;
do
i++;
h=X*theta;

maliyet_top = (h-y).^2;
j(i)=1/(2*m)*sum(maliyet_top);
if j(i)==j(2)
j(1)=j(2);
end
theta = theta - alfa * (1/m)*(X'*(h-y));
teta(i,1) = theta(1,1);
teta(i,2) = theta(2,1);

until (j(i)>j(i-1))

plot(X(:,2),y,'rx','MarkerSize',7)
hold on
plot(X(:,2),X*theta,'-')


disp("Maliyet Yoldulugu:")
j(:)

disp("Teta yolculugu:")
teta

disp("Toplam Gidilen Adımlar: (iterasyon)")
i

disp("Minimum Maliyet Degeri:")
min(j)

disp("Bulunan teta degerleri:")

theta



% MALİYET DEĞERLERİ İLE BİRLİKTE EN DÜŞÜK MALİYET NOKTASINI VE TETA DEĞERLERİNİN YOLUCUĞUNU 3 BOYUTLU BİÇİMDE GÖRMEK İÇİN 3 BOYUTLU GRAFİK OLUŞTURMA
 
			% Maliyet fonksiyonunun hesapladığı maliyet değerlerini matris olarak varsayalım


			% Maliyet değerlerini 3D çizgi grafiğiyle gösterme
			
			figure;
			plot3(teta(:,2), j, '.', 'MarkerSize', 10);
			hold on;
		
			plot3(theta(1,1), min(j), 'r.', 'MarkerSize', 20);
			
			
			legend('Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası','Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası')
			
			
			hold off;
			title('Maliyet Fonksiyonunun Minimizasyonu 3D Çizimi (Mavi Nokta: Maliyet Değeri, Kırmızı Nokta: Destinasyon)');
			xlabel('Theta1');
			ylabel('Maliyet');
			zlabel('Theta0');
			grid on;