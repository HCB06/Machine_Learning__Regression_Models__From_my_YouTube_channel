	function [alfa,beta,j] = otomasyon (X,y,alfa,beta,maliyet)
	
	i=1;
	j=0;
	a=0;
	b=0;
	m=0;
	h=0;
	
	
	
	case1_alfa=alfa;
	case1_beta=beta;
	case_maliyet=min(maliyet);
	
	
	teta=zeros(2,1);
	
	case1_alfa+=0.001;
	case1_beta+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case1_alfa, case1_beta);
	
	if min(maliyet)<case_maliyet
	
	do
	
	a(i) = case1_alfa;
	b(i) = case1_beta;
	
	
	i++;
	
	case1_alfa+=0.001;
	case1_beta+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case1_alfa, case1_beta);
	
	m(i) = min_maliyet(i)=min(maliyet);
	j+=length(maliyet);
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	case_maliyet=min_maliyet(i-1);
	alfa=case1_alfa-0.001;
	beta=case1_beta-0.001;
	
	else 
	
	case1_alfa-=0.001;
	case1_beta-=0.001;
	
	end
	
	%%%
	
	
	case2_alfa=alfa;
	case2_beta=beta;
	
	
	case2_alfa+=0.001;
	case2_beta-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case2_alfa, case2_beta);
	
	if min(maliyet)<case_maliyet
	
	h+=i;
	
	i=1;
	
	do
	h++;
	
	a(h) = case2_alfa;
	b(h) = case2_beta;
	
	i++;
	
	case2_alfa+=0.001;
	case2_beta-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case2_alfa, case2_beta);
	
		m(h) = min_maliyet(i)=min(maliyet);
		j+=length(maliyet);
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	alfa=case2_alfa-0.001;
	beta=case2_beta+0.001;
	
	else 
	
	case2_alfa-=0.001;
	case2_beta+=0.001;
	
	end
	
	
	%%%
	
	
	case3_alfa=alfa;
	case3_beta=beta;
	
	
	case3_alfa-=0.001;
	case3_beta-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case3_alfa, case3_beta);
	
	if min(maliyet)<case_maliyet
	h+=i;
	
	i=1;
	
	do
	h++;
	
	a(h) = case3_alfa;
	b(h) = case3_beta;
	
	i++;
	
	case3_alfa-=0.001;
	case3_beta-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case3_alfa, case3_beta);
	m(h) = min_maliyet(i)=min(maliyet);
	j+=length(maliyet);
	
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	alfa=case3_alfa+0.001;
	beta=case3_beta+0.001;
	
	else 
	
	case3_alfa+=0.001;
	case3_beta+=0.001;
	
	end
	
	
	%%%
	
	
	case4_alfa=alfa;
	case4_beta=beta;
	
	
	case4_alfa-=0.001;
	case4_beta+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case4_alfa, case4_beta);
	
	if min(maliyet)<case_maliyet
	
	h+=i;
	
	i=1;
	
	do
	h++;
	
	a(h) = case4_alfa;
	b(h) = case4_beta;
	
	i++;
	
	case4_alfa-=0.001;
	case4_beta+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case4_alfa, case4_beta);
	
		m(h) = min_maliyet(i)=min(maliyet);
		j+=length(maliyet);
	
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	alfa=case4_alfa+0.001;
	beta=case4_beta-0.001;
	
	else 
	
	case4_alfa+=0.001;
	case4_beta-=0.001;
	
	end
	
	
	%%%
	
	
	case5_alfa=alfa;
	
	
	
	case5_alfa+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case5_alfa, beta);
	
	if min(maliyet)<case_maliyet
	h+=i;
	
	i=1;
	
	do
	h++;
	
		a(h) = alfa;
	b(h) = beta;
	
	i++;
	
	case5_alfa+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case5_alfa, beta);
	
	m(h) = min_maliyet(i)=min(maliyet);
	j+=length(maliyet);
	
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	alfa=case5_alfa-0.001;
	
	else 
	
	case5_alfa-=0.001;
	
	end
	
	%%%
	
		
	case6_alfa=alfa;
	
	
	
	
	case6_alfa-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case6_alfa, beta);
	
	if min(maliyet)<case_maliyet
	
		h+=i;
	
	i=1;
	
	do
	h++;
		a(h) = alfa;
	b(h) = beta;
	
	
	i++;
	
	case6_alfa-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, case6_alfa, beta);
	
	m(h) = min_maliyet(i)=min(maliyet);
	j+=length(maliyet);
	
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	alfa=case6_alfa+0.001;
	
	else
	
	case6_alfa+=0.001;
	
	end
	
	
	
	%%%
	
		
	case7_beta=beta;
	
	
	
	
	case7_beta+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, alfa, case7_beta);
	
	if min(maliyet)<case_maliyet
	
		h+=i;
	
	i=1;
	
	do
	h++;
	
	a(h) = alfa;
	b(h) = beta;
	
	i++;
	
	case7_beta+=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, alfa, case7_beta);

	m(h) = min_maliyet(i)=min(maliyet);
	j+=length(maliyet);
	
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	beta=case7_beta-0.001;
	
	else 
	
	case7_beta-=0.001;
	
	end
	
	
	%%%
	
		
	case8_beta=beta;
	
	
	
	
	case8_beta-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, alfa, case8_beta);
	
	if min(maliyet)<case_maliyet
	
		h+=i;
	
	i=1;
	
	do
	h++;
	
	a(h) = alfa;
	b(h) = beta;
	
	i++;
	
	case8_beta-=0.001;
	
	[~,~,~,maliyet] = optimizasyon(X, y, teta, alfa, case8_beta);

	m(h) = min_maliyet(i)=min(maliyet);
	j+=length(maliyet);
	
	
	if i==2
	min_maliyet(i-1)=min(maliyet);
	end
	
	until(min_maliyet(i)>min_maliyet(i-1))
	j+=i;
	
	case_maliyet=min_maliyet(i-1);
	beta=case8_beta+0.001;
	
	else 
	
	case8_beta+=0.001;
	
	end

	
	
	%{									
	figure;						not : BU GRAFİKLERİ AÇTIĞINIZDA ORTAM DOSYASINDAKİ GRAFİKLERİ KAPATIN.(ÇAKIŞMA OLABİLİYOR) 
	hold on
	scatter3(a,b,m, 50 ,m)
	colormap (jet);
	colorbar;
	xlabel('Alfanın Başlangıç Değeri');
	ylabel('Betanın Başlangıç Değeri');
	zlabel('Minimum Maliyet Değeri');
	title('Otomasyon Yolculuğu');
	
	
	[m] = meshgrid (m);
	
	figure;
	surf(a,b,m);
	xlabel('Alfa');
	ylabel('Beta');
	zlabel('Minimum Maliyet');
	title('Otomasyon Yüzey Grafiği');
	
	colormap(jet);
	colorbar;


	%}
	