	function [teta,theta0_vals,theta1_vals,maliyet,alpha,i] = optimizasyon (X,y,teta,alfa,beta)

	i=1;
	m=length(y);

	% KADEMELİ MALİYET AZALTMA

	do

	i++;


	h = X*teta;

	maliyet_top = (h-y).^2;
	
	maliyet(i)=1/(2*m)*sum(maliyet_top(:,1));

	if i==2
	maliyet(i-1) = maliyet(i);
	end


	if i>1
	
	if maliyet(i)<maliyet(i-1)
	
	
		
	
	%teta(1,i) = teta(1,1);
	%tata(2,i) = teta(2,1);
	
	beta-=0.001;
	alfa-=0.001;
	

	end
	end
	
	theta0_vals(i,1)=teta(1,1);
	theta1_vals(i,1)=teta(2,1);


	

	teta(1,1)+=beta;
	teta(2,1)+=alfa;
	alpha(i,1)=alfa;
	
	
	until(maliyet(i)>maliyet(i-1))