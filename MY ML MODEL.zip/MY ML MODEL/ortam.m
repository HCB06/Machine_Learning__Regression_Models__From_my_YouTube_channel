function ortam(X,y)

	alfa=0.0001;
	beta=0.0001;
	
	s=0;
	
	if alfa==0.0001 && beta==0.0001
	 s++;
	end
	
	m=length(y);
	
	X = [ones(m,1),X];
	
	teta=zeros(2,1);
		
		[teta, theta0_vals, theta1_vals, maliyet,alpha] = optimizasyon(X, y, teta, alfa, beta);
		
		[alfa,beta,j] = otomasyon(X,y,alfa,beta,maliyet);
		
			
		disp('Girilen veri seti için bulunan Alfa hiperparametresi:')
		alfa
		disp('Girilen veri seti için bulunan Beta hiperparametresi:')
		beta
		disp('Hiperparametreleri bulmak için toplam gidilen adım sayısı:')
		j

		%%%
	
	maliyet_yolculugu(:,1)=maliyet;
	
	i=0;
	
	
	for i=1:1 length(maliyet_yolculugu(:,1))
	
	maliyet_yolculugu(i,2)=maliyet_yolculugu(i,1);
	
	
	
	end
	
		%%%

	min_maliyet1=min(maliyet_yolculugu(:,2));
	
	
					
					
	%length(maliyet_yolculugu)
					
	theta=cat(2,theta0_vals,theta1_vals);
	theta=theta(:,1:2);
					
	for i=2:1:length(maliyet_yolculugu(:,2)) 
	
			if maliyet_yolculugu(i,2)!=0 && X1!=0
			
				min_maliyet1=min(maliyet_yolculugu(:,2));
					
			end
		end
		
	for i=2:1:length(maliyet_yolculugu(:,1))
	
			if maliyet_yolculugu(i,1)!=0
			
				min_maliyet0=min(maliyet_yolculugu(:,1));

					end
	end
					
					
										
				if s!=1							
					disp("Maliyet Yolculugu:")
					maliyet_yolculugu(:,1)
						
					disp("Teta0 ve Teta1 Yolculugu:")
					teta_yol= horzcat(theta0_vals,theta1_vals(:,1))
					disp("Toplam Gidilen Adımlar: (iterasyon)")
					i-1

					disp("Minimum Hesaplanan Maliyet:")
					min(maliyet_yolculugu(:,1))
						
					disp('Bulunan Optimum Teta Değeri:')
					teta(1,1)
					teta(2,1)
				end		
				
						
%{ not: EĞER OTOMASYONDA Kİ GRAFİKLERİ GÖRMEK İSTİYORSANIZ BU GRAFİKLERİ BUNU KULLANARAK KAPATIN.(ÇAKIŞMA OLABİLİYOR) %} 
						
	% OPTİMUM TETA DEĞERLERİNİ KULLANARAK ÇİZGİSEL MODEL OLUŞTURMA

			m=length(maliyet_yolculugu);
			p = ones(m, 1) * (1:m); 
			v = maliyet_yolculugu(:,1) * ones(1, m);


			plot(X(:,2),y,'rx','MarkerSize',7)
			hold on

			plot(X(:,2),X*teta,'-')
			legend('Gerçek Karşılığı','Modelin Tahmini')
			

	% MALİYET DEĞERLERİNİN YOLUCUĞUNU GÖRÜNTÜLEMEK İÇİN YÜZEYSEL GRAFİK OLUŞTURMA
 
			figure;
			surf(p, v, v);
			title('Aşağı Doğru Eğim Alması Gereken Maliyet Değerleri');
			xlabel('X Ekseni');
			ylabel('Y Ekseni');
			zlabel('Z Ekseni');

			figure;
			% l ve b matrislerini oluştur
			adimlar = alpha;
			[l, b] = meshgrid(adimlar, maliyet_yolculugu(:,1));


	


			% Maliyet değerlerini Z matrisine at
			n = maliyet_yolculugu';

			% Contour grafiğini çiz
			contour(l, b, b, 'LineWidth', 2);
			title('0 A Yaklaştıkça Mor Renge Dönmesi Gereken Maliyet Değerlerinin Yolculuk Grafiği');
			xlabel('Adımlar');
			ylabel('Maliyet Değerleri');
			colorbar;  % Renk skalasını gösterir



	% MALİYET DEĞERLERİ İLE BİRLİKTE EN DÜŞÜK MALİYET NOKTASINI VE TETA DEĞERLERİNİN YOLUCUĞUNU 3 BOYUTLU BİÇİMDE GÖRMEK İÇİN 3 BOYUTLU GRAFİK OLUŞTURMA
 
			% Maliyet fonksiyonunun hesapladığı maliyet değerlerini matris olarak varsayalım


			% Maliyet değerlerini 3D çizgi grafiğiyle gösterme
			figure;
			plot3(theta0_vals(:,1), maliyet, '.', 'MarkerSize', 10);
			hold on;
		
			plot3(teta(2,1), min_maliyet0, 'r.', 'MarkerSize', 20);
			
			legend('Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası','Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası')
			
			
			hold off;
			title('Maliyet Fonksiyonunun Minimizasyonu 3D Çizimi (Mavi Nokta: Maliyet Değeri, Kırmızı Nokta: Destinasyon)');
			xlabel('Theta1');
			ylabel('Maliyet');
			zlabel('Theta0');
			grid on;
			
	% LİNEER REGRESYON MODELİNİN GENEL BAŞARISINI DEĞERLENDİMEK VE BAŞKA MODELE GEREK OLUP OLMADIĞINI KONTROL ETMEK İÇİN MALİYET YAŞAM DÖNGÜSÜ TABLOSU OLUŞTURMA
			
			figure;
			bar(theta0_vals,maliyet_yolculugu(:,1));
			for i = 1:length(maliyet_yolculugu)
				text(theta0_vals(i,1), maliyet_yolculugu(i,1), num2str(maliyet_yolculugu(i,1)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
			end
			xlabel('Teta Değerleri');
			ylabel('Maliyet Değerleri');
			title('Modelin Lineer Regresyonla Uyumu " Minimum Maliyeti İyi Belirle"')


			

