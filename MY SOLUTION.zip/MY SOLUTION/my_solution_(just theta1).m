function gradyan(X,y)

	% TETA DEĞERLERİNİN BAŞLANGIÇ NOKTALARINI BELİRLEME
    
	X1=0;  % ŞU ANLIK BURAYI KAPTIYORUZ BUNU BİR SWİTCH GİBİ DÜŞÜNÜN BU ALANLA İŞİMİZ YOK
	alfa=0.0445;
	m=length(y);
	i=0;
	j=0;
	teta=zeros(1,2);
	
	maliyet=zeros(1,2);
	
	% TETA 1 İÇİN KADEMELİ MALİYET AZALTMA

	do

	i++;


	h = (teta(1,1)+teta(1,2))*X;

	maliyet_top = (h-y).^2;
	maliyet(i,1)=1/(2*m)*sum(maliyet_top);



	if i>1
	if maliyet(i,1)>maliyet(i-1,1) && i==1
	alfa+=0.001;
	j++;
	if j==1
	alfa-=0.16;
	end
	
	end
	if maliyet(i,1)<maliyet(i-1,1) && teta(1,1)<0
	
	theta0_vals(i,1)=teta(1,1);

	alfa+=0.001;
	end
	if maliyet(i,1)<maliyet(i-1,1) && teta(1,1)>0
	
	
	tata(i,1) = teta(1,1)
	
	alfa-=0.001;
	
	
	
	end
	end
	
	
theta0_vals(i,1)=teta(1,1);
	
	

	teta(1,1)+=alfa;
	
	
	
	until(maliyet(i,1)>maliyet(1,1))
		
		
		
		
		theta1_vals=zeros(length(theta0_vals),1);
		
		
	
	
	if X1!=0 % SWİTCH KAPALI OLDUĞUNDAN GİRMİYOR
	
	i=0;
	

	alfa=0.08;
	j=0;
	teta(1,1)=0;
	do


	i++;


	h = (teta(1,1)+teta(1,2))*X;

	maliyet_top = (h-y).^2;
	maliyet(i,2)=1/(2*m)*sum(maliyet_top);



	if i>1
	if maliyet(i,2)>maliyet(i-1,2) && i==2
	alfa+=0.001;
	j++;
	if j==1
	alfa-=0.16;
	end
	
	end
	if maliyet(i,2)<maliyet(i-1,2) && teta(1,2)>0
	
	theta1_vals(i,1)=teta(1,2);

	alfa-=0.001;
	
	
	end
	
	if maliyet(i,2)<maliyet(i-1,2) && teta(1,2)<0
	
	theta1_vals(i,1)=teta(1,2);

	alfa+=0.001;
	end
	end
	
	

	
	

	teta(1,2)+=alfa;
	
	
	
	until(maliyet(i,2)>maliyet(1,2))
	end
	

	%%%
		
		% TETA 1 İÇİN GEREKLİ DÜZELTMELER VE MALİYET YOLCULUĞUNU LİSTELEME
		
		
		alfa=0.0445;
		teta(1,1)=0;
		j=1;
		
		do
		
		j++;
		teta(1,1)+=alfa;
		alfa-=0.001;
		alpha(j,1)=alfa;


		until(maliyet(j,1)>maliyet(j-1,1))

		for t=1:1:j-1
		maliyet_yolculugu(t,1)=maliyet(t,1);

		end

		i=0;

	
	

		
		if X1!=0 %SWİTCH KAPALI OLDUĞUNDAN GİRMİYOR
		
		alfa=0.08;
		teta(1,2)=0;


		j=1;


		do

		j++;
		teta(1,2)+=alfa;
		alfa-=0.001;


		until(maliyet(j,2)>maliyet(j-1,2))
		for t=1:1:j-1
		maliyet_yolculugu(t,2)=maliyet(t,2);

		end
		for j=1:1:length(theta1_vals)
		
		alfa=0.08;
		
		if theta1_vals(j,1)==0

		teta(1,2)-=alfa;
		alfa-=0.001;
		end
		end
		
		end

	%%%
		
		
		
	if X1==0 % SWİTCH KAPALI OLDUĞUNDAN GİRMİYOR
	
	
	
	for i=1:1 length(maliyet_yolculugu(:,1))
	
	maliyet_yolculugu(i,2)=maliyet_yolculugu(i,1);
	
	
	
	end
	
	end
	
	%%%

				min_maliyet1=min(maliyet_yolculugu(:,2));
	
	
					
					
					%length(maliyet_yolculugu)
					
					theta=cat(2,theta0_vals,theta1_vals);
					theta=theta(:,1:2);
					
					for i=2:1:length(maliyet_yolculugu(:,2)) 
					if maliyet_yolculugu(i,2)!=0 && X1!=0
					min_maliyet1=min(maliyet_yolculugu(:,2));
					
					end
					end
						for i=2:1:length(maliyet_yolculugu(:,1))
					if maliyet_yolculugu(i,1)!=0
					min_maliyet0=min(maliyet_yolculugu(:,1));

					end
					end
					
					
					
						
disp("Maliyet Yolculugu:")
 maliyet_yolculugu(:,1)
	
		disp("Teta Yolculugu:")
theta0_vals(:,1)
disp("Toplam Gidilen Adımlar: (iterasyon)")
j-1

disp("Minimum Hesaplanan Maliyet:")
min(maliyet_yolculugu(:,1))
	
	disp('Bulunan Optimum Teta Değeri:')
	teta(1,1)
	teta(1,2)
	

	l=length(X(:,1));
	l(:,1)=-2;

					

	% OPTİMUM TETA DEĞERLERİNİ KULLANARAK ÇİZGİSEL MODEL OLUŞTURMA

			m=length(maliyet_yolculugu);
			p = ones(m, 1) * (1:m); 
			v = maliyet_yolculugu(:,1) * ones(1, m);


			plot(X,y,'rx','MarkerSize',7)
			hold on

			plot(X(:,1),(teta(1,1)+teta(1,2))*X,'-')
			legend('Gerçek Karşılığı','Modelin Tahmini')

	% MALİYET DEĞERLERİNİN YOLUCUĞUNU GÖRÜNTÜLEMEK İÇİN YÜZEYSEL GRAFİK OLUŞTURMA
 
			figure;
			surf(p, v, v);
			title('Aşağı Doğru Eğim Alması Gereken Maliyet Değerleri');
			xlabel('X Ekseni');
			ylabel('Y Ekseni');
			zlabel('Z Ekseni');

			figure;
			% l ve b matrislerini oluştur
			adimlar = alpha;
			[l, b] = meshgrid(adimlar, maliyet_yolculugu(:,1));


	


			% Maliyet değerlerini Z matrisine at
			n = maliyet_yolculugu';

			% Contour grafiğini çiz
			contour(l, b, b, 'LineWidth', 2);
			title('0 A Yaklaştıkça Mor Renge Dönmesi Gereken Maliyet Değerlerinin Yolculuk Grafiği');
			xlabel('Adımlar');
			ylabel('Maliyet Değerleri');
			colorbar;  % Renk skalasını gösterir



	% MALİYET DEĞERLERİ İLE BİRLİKTE EN DÜŞÜK MALİYET NOKTASINI VE TETA DEĞERLERİNİN YOLUCUĞUNU 3 BOYUTLU BİÇİMDE GÖRMEK İÇİN 3 BOYUTLU GRAFİK OLUŞTURMA
 
			% Maliyet fonksiyonunun hesapladığı maliyet değerlerini matris olarak varsayalım


			% Maliyet değerlerini 3D çizgi grafiğiyle gösterme
			figure;
			plot3(theta0_vals(:,1), maliyet(:,1), '.', 'MarkerSize', 10);
			hold on;
		
			plot3(teta(1,1), min_maliyet0, 'r.', 'MarkerSize', 20);
			
	if X1!=0 %SWİTCH KAPALI OLDUĞUNDAN GİRMİYOR
			
			hold on;
					plot3(theta1_vals(:,1),maliyet_yolculugu(:,2), 'br.', 'MarkerSize', 10);
			hold on;
			
			plot3(teta(1,2), min_maliyet1, 'm.', 'MarkerSize', 20);
			
	end
			
			legend('Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası','Theta1 için Maliyet Değerleri','Theta1 için Minimum Maliyet Noktası')
			
			
			hold off;
			title('Maliyet Fonksiyonunun Minimizasyonu 3D Çizimi (Mavi Nokta: Maliyet Değeri, Kırmızı Nokta: Destinasyon)');
			xlabel('Theta1');
			ylabel('Maliyet');
			zlabel('Theta0');
			grid on;
			
	% LİNEER REGRESYON MODELİNİN GENEL BAŞARISINI DEĞERLENDİMEK VE BAŞKA MODELE GEREK OLUP OLMADIĞINI KONTROL ETMEK İÇİN MALİYET YAŞAM DÖNGÜSÜ TABLOSU OLUŞTURMA
			
			figure;
			bar(theta0_vals,maliyet_yolculugu(:,1));
			for i = 1:length(maliyet_yolculugu)
				text(theta0_vals(i,1), maliyet_yolculugu(i,1), num2str(maliyet_yolculugu(i,1)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
			end
			xlabel('Teta Değerleri');
			ylabel('Maliyet Değerleri');
			title('Modelin Lineer Regresyonla Uyumu " Minimum Maliyeti İyi Belirle"')

